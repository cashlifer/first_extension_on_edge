# Get started with viewing and changing the DOM in DevTools

➡️ **[Open the demo](https://microsoftedge.github.io/Demos/devtools-dom-get-started/)** ⬅️

This is the source code for the demo page used in the Microsoft Edge DevTools tutorial: [Get started with viewing and changing the DOM](https://learn.microsoft.com/microsoft-edge/devtools-guide-chromium/dom/).
