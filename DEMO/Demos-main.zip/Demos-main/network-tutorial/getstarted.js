document.querySelector('#gsbutton').addEventListener("click", () => {
  fetch('./getstarted.json');
});
