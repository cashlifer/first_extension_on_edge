# DevTools Network activity tutorial Demo

➡️ **[Open the demo](https://microsoftedge.github.io/Demos/network-tutorial/)** ⬅️

This is the source code for the demo page used in the Microsoft Edge DevTools tutorial: [Inspect network activity](https://learn.microsoft.com/en-us/microsoft-edge/devtools-guide-chromium/network/).
