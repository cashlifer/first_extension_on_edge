# Animal Shelter - DevTools accessibility-testing features demo

➡️ **[Open the demo](https://microsoftedge.github.io/Demos/devtools-a11y-testing/)** ⬅️

This is the source code for the demo page used in the Microsoft Edge DevTools accessibility testing documentation. The documentation spans several pages, but its entry point is the [Accessibility-testing features](https://learn.microsoft.com/microsoft-edge/devtools-guide-chromium/accessibility/reference) page.

**Note**: This demo page contains **accessibility issues**, this is on purpose, to demonstrate DevTools accessibility testing features.
