# Support forcing the `:target` CSS state in DevTools

➡️ **[Open the demo](https://microsoftedge.github.io/Demos/devtools-target-pseudo/)** ⬅️

This is the source code for the demo page used in the Microsoft Edge DevTools release note: [Support forcing the :target CSS state](https://learn.microsoft.com/microsoft-edge/devtools-guide-chromium/whats-new/2021/01/devtools#support-forcing-the-target-css-state).
