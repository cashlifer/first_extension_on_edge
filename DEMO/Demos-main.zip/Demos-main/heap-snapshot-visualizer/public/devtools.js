var panels = chrome.devtools.panels;

panels.create(
    "Heap Snapshot Visualizer",
    "icon-48.png",
    "index.html"
);