console.log('DevTools extension API: ');
console.log(chrome.devtools);