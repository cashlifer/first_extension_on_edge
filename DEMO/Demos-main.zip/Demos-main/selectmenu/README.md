OpenUI's `<selectlist>` component used to be named `<selectmenu>`. The corresponding demo has now moved to the `../selectlist` directory.
