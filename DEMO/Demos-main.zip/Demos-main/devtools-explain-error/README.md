# Explain console errors and warnings in Copilot in Edge

➡️ **[Open the demo](https://microsoftedge.github.io/Demos/devtools-explain-error/)** ⬅️

This is the source code for the demo page used in the Microsoft Edge DevTools document: [Explain DevTools Console errors and source code using Copilot in Edge](https://learn.microsoft.com/microsoft-edge/devtools-guide-chromium/experimental-features/copilot-explain).
