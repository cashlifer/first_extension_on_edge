# DevTools performance features reference - View activities in a table

➡️ **[Open the demo](https://microsoftedge.github.io/Demos/devtools-performance-activitytabs/)** ⬅️

This is the source code for the demo page used in the Microsoft Edge DevTools docs: [Performance features reference > View activities in a table](https://learn.microsoft.com/microsoft-edge/devtools-guide-chromium/evaluate-performance/reference#view-activities-in-a-table).
