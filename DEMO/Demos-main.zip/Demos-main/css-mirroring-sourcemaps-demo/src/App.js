import AppHeader from './AppHeader.js';
import './App.css';

function App() {
  return (
    <div className="App">
      <AppHeader />
    </div>
  );
}

export default App;
