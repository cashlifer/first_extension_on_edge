# Get started with debugging JavaScript in DevTools

➡️ **[Open the demo](https://microsoftedge.github.io/Demos/devtools-js-get-started/)** ⬅️

This is the source code for the demo page used in the Microsoft Edge DevTools tutorial: [Get started with debugging JavaScript](https://learn.microsoft.com/microsoft-edge/devtools-guide-chromium/javascript/).
