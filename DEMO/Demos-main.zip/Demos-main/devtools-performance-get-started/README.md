# Get started with analyzing Runtime performance in DevTools

➡️ **[Open the demo](https://microsoftedge.github.io/Demos/devtools-performance-get-started/)** ⬅️

This is the source code for the demo page used in the Microsoft Edge DevTools tutorial: [Introduction to the Performance tool](https://learn.microsoft.com/microsoft-edge/devtools-guide-chromium/evaluate-performance/).
