# Get started with viewing and changing CSS in DevTools

➡️ **[Open the demo](https://microsoftedge.github.io/Demos/devtools-css-get-started/)** ⬅️

This is the source code for the demo page used in the Microsoft Edge DevTools tutorial: [Get started with viewing and changing CSS](https://learn.microsoft.com/microsoft-edge/devtools-guide-chromium/css/).
