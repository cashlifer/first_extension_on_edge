# Basic To Do App

➡️ **[Open the demo](https://microsoftedge.github.io/Demos/demo-to-do/)** ⬅️

A simple To Do app with vanilla JavaScript.  This demo is used for the following:
*  Various screenshots in the [Microsoft Edge DevTools documentation](https://learn.microsoft.com/microsoft-edge/devtools-guide-chromium/).
*  [Opening DevTools and the DevTools browser](https://learn.microsoft.com/en-us/microsoft-edge/visual-studio-code/microsoft-edge-devtools-extension/open-devtools-and-embedded-browser), for the DevTools extension for Visual Studio Code.
