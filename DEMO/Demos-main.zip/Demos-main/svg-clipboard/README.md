# SVG support in the Async Clipboard API

➡️ **[Open the demo](https://microsoftedge.github.io/Demos/svg-clipboard/)** ⬅️

This demo showcases the support for SVG format in the Async Clipboard API.
