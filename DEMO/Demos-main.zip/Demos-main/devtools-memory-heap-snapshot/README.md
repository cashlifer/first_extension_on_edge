# Record heap snapshots in DevTools

This is the source code for the demo pages used in the Microsoft Edge DevTools tutorial: [Record heap snapshots](https://learn.microsoft.com/microsoft-edge/devtools-guide-chromium/memory-problems/heap-snapshots).

Demo pages:

* [example-03.html](https://microsoftedge.github.io/Demos/devtools-memory-heap-snapshot/example-03.html)
* [example-06.html](https://microsoftedge.github.io/Demos/devtools-memory-heap-snapshot/example-06.html)
* [example-07.html](https://microsoftedge.github.io/Demos/devtools-memory-heap-snapshot/example-07.html)
* [example-08.html](https://microsoftedge.github.io/Demos/devtools-memory-heap-snapshot/example-08.html)
* [example-09.html](https://microsoftedge.github.io/Demos/devtools-memory-heap-snapshot/example-09.html)
