# DevTools Workspaces Demo

➡️ **[Open the demo](https://microsoftedge.github.io/Demos/workspaces/)** ⬅️

This is the source code for the demo page used in the Microsoft Edge DevTools tutorial: [Edit files with Workspaces](https://learn.microsoft.com/microsoft-edge/devtools-guide-chromium/workspaces).
