# Create your own DevTools extension

This is the source code for the tutorial to create a Microsoft Edge extension that extends DevTools: [Create a DevTools extension](https://learn.microsoft.com/microsoft-edge/extensions-chromium/developer-guide/devtools-extension).
