# My new demo

➡️ **[Open the demo](https://microsoftedge.github.io/Demos/my-new-demo/)** ⬅️

Use this file to describe what the demo is about and how to use it.

Consider adding links to external resources like specifications.

Mention the minimum system requirements too.
