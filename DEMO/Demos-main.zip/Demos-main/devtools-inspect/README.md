# Analyze pages using the Inspect tool in DevTools

➡️ **[Open the demo](https://microsoftedge.github.io/Demos/devtools-inspect/)** ⬅️

This is the source code for the demo page used in the Microsoft Edge DevTools tutorial: [Analyze pages using the Inspect tool](https://learn.microsoft.com/microsoft-edge/devtools-guide-chromium/css/inspect).
