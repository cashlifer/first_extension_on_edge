# Interact with the DOM using the Console

➡️ **[Open the demo](https://microsoftedge.github.io/Demos/devtools-console-dom-interactions/)** ⬅️

This is the source code for the demo page used in the Microsoft Edge DevTools tutorial: [Interact with the DOM using the Console](https://learn.microsoft.com/microsoft-edge/devtools-guide-chromium/console/console-dom-interaction).
