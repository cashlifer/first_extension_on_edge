export enum TodoStatus {
  ACTIVE,
  COMPLETED,
}
