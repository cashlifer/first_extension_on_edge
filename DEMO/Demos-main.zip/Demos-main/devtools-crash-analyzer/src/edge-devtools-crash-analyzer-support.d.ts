declare module '@microsoft/edge-devtools-crash-analyzer-support';
