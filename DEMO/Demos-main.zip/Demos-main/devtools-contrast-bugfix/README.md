# Improving contrast in Microsoft Edge DevTools: A bugfix case study

➡️ **[Open the demo](https://microsoftedge.github.io/Demos/devtools-contrast-bugfix/)** ⬅️

This folder contains the source code for a demo page that is used in the following Microsoft Edge blog post: [Improving contrast in Microsoft Edge DevTools: A bugfix case study](https://blogs.windows.com/msedgedev/2021/06/15/improving-contrast-in-microsoft-edge-devtools-a-bugfix-case-study/).
